public class ListTester {
	public static void main(String[] args){
        SinglyLinkedList lists = new SinglyLinkedList();
        
        lists.insert(1).insert(2).insert(3);
        // System.out.println(lists);
        
    }

}

